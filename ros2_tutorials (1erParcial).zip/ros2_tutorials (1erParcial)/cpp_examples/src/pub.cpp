#include <chrono>
#include <functional>
#include <memory>
#include <string>

#include "rclcpp/rclcpp.hpp"
#include "std_msgs/msg/string.hpp"

using namespace std::chrono_literals;

class MinimalPublisher : public rclcpp::Node
{
  // crear variables
  rclcpp::TimerBase::SharedPtr timer_;
  rclcpp::Publisher<std_msgs::msg::String>::SharedPtr publisher_;
  size_t count_;

public:
  MinimalPublisher()
      : Node("pub"), count_(0)
  {
    publisher_ = this->create_publisher<std_msgs::msg::String>("topic1", 10);
    timer_ = this->create_wall_timer(
        100ms, std::bind(&MinimalPublisher::timer_callback, this));
  }

private:
  void timer_callback()
  {
    auto message = std_msgs::msg::String();
    message.data = "Hello, class! " + std::to_string(count_++);
    RCLCPP_INFO(this->get_logger(), "Publicando msg: '%s'", message.data.c_str());
    // std::cout<<"hola \n";
    publisher_->publish(message);
  }
};

int main(int argc, char *argv[])
{
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<MinimalPublisher>());
  rclcpp::shutdown();
  return 0;
}