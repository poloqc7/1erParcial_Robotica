#include <memory>

#include "rclcpp/rclcpp.hpp"
#include "std_msgs/msg/string.hpp"
using std::placeholders::_1;

class MinimalSubscriber : public rclcpp::Node
{
  rclcpp::Subscription<std_msgs::msg::String>::SharedPtr subscription_;

public:
  MinimalSubscriber()
      : Node("sub_nodo")
  {
    subscription_ = this->create_subscription<std_msgs::msg::String>(
        "topic2", 10, std::bind(&MinimalSubscriber::topic_callback, this, _1));
  }

private:
  void topic_callback(const std_msgs::msg::String &msg) const
  {
    RCLCPP_INFO(this->get_logger(), "Me ha llegado: '%s'", msg.data.c_str());
  }
};

int main(int argc, char *argv[])
{
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<MinimalSubscriber>());
  rclcpp::shutdown();
  return 0;
}